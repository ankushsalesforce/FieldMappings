<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Account revenue To Item Revenue</label>
    <protected>false</protected>
    <values>
        <field>IsActive__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Object_Mapping__c</field>
        <value xsi:type="xsd:string">Account_To_Items</value>
    </values>
    <values>
        <field>Source_Field__c</field>
        <value xsi:type="xsd:string">AnnualRevenue</value>
    </values>
    <values>
        <field>Target_Field__c</field>
        <value xsi:type="xsd:string">Annual_Revenue__c</value>
    </values>
</CustomMetadata>
